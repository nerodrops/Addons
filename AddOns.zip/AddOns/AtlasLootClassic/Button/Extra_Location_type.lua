local AtlasLoot = _G.AtlasLoot
local Location = AtlasLoot.Button:AddExtraType("Location")
local AL = AtlasLoot.Locales

function Location.OnSet(mainButton, descFrame)

end
