# Bartender4

## [4.8.3-20-g01a4a55](https://github.com/Nevcairiel/Bartender4/tree/01a4a555c529a4d57d1bea27819e61d493dda141) (2019-08-10)
[Full Changelog](https://github.com/Nevcairiel/Bartender4/compare/4.8.3...01a4a555c529a4d57d1bea27819e61d493dda141)

- Add another classic guard for LibDualSpec  
- Another attempt  
- Try disabling wowi upload for classic  
- Build classic version first, so that the retail version is seen as "more recent"  
- Add Classic support to Double-Wide and Tripple-Stacked presets  
- Tweak bag bar position on classic  
- Fix default page for warrior beserker stance, and only use on Classic  
- Remove support for ButtonFacade, its been dead for years  
- Don't use LibDualSpec at all on classic  
- Avoid loading LibDualSpec on classic  
- Build a classic version  
- Add TOC version for classic  
- Handle XP/Rep bar on classic  
- Fix LuaCheck  
- Handle the MainMenuBarPerformanceBarFrame on classic  
- Improve positioning of micromenu and bag bar on classic (and Blizzard preset)  
- Warrior stances for classic  
- Disable talent frame hook on classic  
- Hide the MultiCastActionBar  
- Check if SpellFlyout actually exists  
